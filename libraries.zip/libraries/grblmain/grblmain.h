#ifndef grblmain_h
#define grblmain_h 

void startGrbl();

#endif